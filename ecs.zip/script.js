document.getElementById("link").href = "https://classroom.google.com/u/0/h";

function myfunction(){
  document.getElementById("epic").innerHTML = "Thanos";
	document.getElementById("epic").style.color = "purple";
}

function WannaturnRED(){
	document.getElementById("WannabecomeANGRY").style.color="red";
}


function coolio(){
	document.getElementById("coolio").style.color="blue";
}

function clicktime() {
	document.getElementById("clicktime").style.fontFamily="Tahoma";
}


function changefont() {
	document.getElementById("font").style.fontFamily="Impact"
}

function Hidingtheimage() {
  var x = document.getElementById("epicimage");
  if (x.style.display === "none") {
  x.style.display = "block";
  } else {
  x.style.display = "none";
  }
}